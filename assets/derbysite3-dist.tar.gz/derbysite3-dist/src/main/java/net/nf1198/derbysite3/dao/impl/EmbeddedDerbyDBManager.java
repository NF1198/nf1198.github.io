/*
 * The MIT License
 *
 * Copyright 2016 Nicholas Folse.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package net.nf1198.derbysite3.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.nf1198.derbysite3.util.JDBCUtil;

/**
 * This class contains static methods for working with the embedded derby
 * database.
 *
 * @author nickfolse
 */
public final class EmbeddedDerbyDBManager {

    private static final Logger LOG = Logger.getLogger(EmbeddedDerbyDBManager.class.getName());

    final public static String DBINFO_TABLE = "DBINFO"; // Don't change this value
    // unless you also create a
    // dbUpgrade version
    // migration!

    final public static String PERSONS_TABLE = "PERSONS"; // Don't change this value
    // unless you also create a
    // dbUpgrade version
    // migration!

    public static void dbUpgrade() {
        try (final Connection conn = EmbeddedDerbyConnectionPool.getDefault().getConnection();) {
            boolean done = false;
            while (!done) {
                switch (getDBVersion(conn)) {
                    case 0:
                        // migrate database from level 0 (new database) to version 1

                        try (Statement stmt = conn.createStatement()) {
                            conn.setAutoCommit(false);
                            stmt.addBatch("CREATE TABLE " + DBINFO_TABLE
                                    + "(ID INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) CONSTRAINT DBINFO_PK PRIMARY KEY, K VARCHAR(50), V VARCHAR(50))");
                            stmt.addBatch("CREATE TABLE " + PERSONS_TABLE
                                    + "(ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY CONSTRAINT PERSONS_PK PRIMARY KEY, FIRSTNAME VARCHAR(50), LASTNAME VARCHAR(50), FIRSTNAME_UPPER VARCHAR(50) GENERATED ALWAYS AS (UPPER(FIRSTNAME)), LASTNAME_UPPER VARCHAR(50) GENERATED ALWAYS AS (UPPER(LASTNAME)), DOB DATE)");
                            stmt.addBatch("CREATE INDEX PERSONS_FIRST ON PERSONS(FIRSTNAME_UPPER)");
                            stmt.addBatch("CREATE INDEX PERSONS_LAST ON PERSONS(LASTNAME_UPPER)");
                            stmt.addBatch("INSERT INTO " + DBINFO_TABLE + " (K, V) VALUES ('VERSION', '1')");
                            stmt.executeBatch();
                            conn.commit();
                        } catch (SQLException e) {
                            LOG.log(Level.SEVERE, "Error initializing database (0->1)", e);
                            done = true;
                        }
                        break;
                    case 1:
                        done = true;
                        break;
                }
            }
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
    }

    
    public static int getDBVersion(Connection conn) {

        int version = -1; // version undefined

        // check if dbInfo table exists, if so check the version
        if (JDBCUtil.getTables(conn).contains(DBINFO_TABLE)) {
            try (final Statement stmt = conn.createStatement();
                    final ResultSet result = stmt
                    .executeQuery("SELECT V FROM " + DBINFO_TABLE + " WHERE K='VERSION'")) {
                if (result.next()) {
                    version = Integer.parseInt(result.getString("V"));
                }
            } catch (SQLException | NumberFormatException e) {
                LOG.log(Level.SEVERE, "Error retrieving database version", e);
            }
        } else {
            version = 0;
        }

        return version;
    }
}
