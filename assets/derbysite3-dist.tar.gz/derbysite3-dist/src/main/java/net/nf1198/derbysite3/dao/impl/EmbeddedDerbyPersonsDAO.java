/*
 * The MIT License
 *
 * Copyright 2016 Nicholas Folse.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package net.nf1198.derbysite3.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.nf1198.derbysite3.dao.PersonsDAO;
import net.nf1198.derbysite3.data.Person;
import static net.nf1198.derbysite3.dao.impl.EmbeddedDerbyDBManager.*;

/**
 *
 * @author nickfolse
 */
public class EmbeddedDerbyPersonsDAO implements PersonsDAO {

    private static final Logger LOG = Logger.getLogger(EmbeddedDerbyPersonsDAO.class.getName());

    static {
        EmbeddedDerbyDBManager.dbUpgrade();
    }

    private Connection getConnection() throws SQLException {
        return EmbeddedDerbyConnectionPool.getDefault().getConnection();
    }

    @Override
    public Person create(final Person p) {
        final String STMT = "INSERT INTO " + PERSONS_TABLE + "(FIRSTNAME, LASTNAME, DOB) VALUES(?, ?, ?)";
        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT, 1);) {
            s.clearParameters();
            s.setString(1, p.getFirstName());
            s.setString(2, p.getLastName());
            s.setDate(3, java.sql.Date.valueOf(p.getDOB()));
            final long createdID = s.executeUpdate();
            s.getConnection().commit();
            p.setID(createdID);
            return p;
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
        return p;
    }

    @Override
    public Person read(Integer id) throws IllegalArgumentException {
        final String STMT = "SELECT ID, LASTNAME, FIRSTNAME, DOB FROM " + PERSONS_TABLE + " WHERE ID=?";
        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT);) {
            s.setInt(1, id);
            try (ResultSet result = s.executeQuery()) {
                if (result.next()) {
                    final int ID = result.getInt("ID");
                    final String lastName = result.getString("LASTNAME");
                    final String firstName = result.getString("FIRSTNAME");
                    final LocalDate dob = result.getDate("DOB").toLocalDate();
                    return new Person(ID, firstName, lastName, dob);
                } else {
                    throw new IllegalArgumentException("Specified record does not exist");
                }
            }
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
        return new Person();
    }

    @Override
    public Person update(Person p) {
        final String STMT = "UPDATE " + PERSONS_TABLE + " SET FIRSTNAME=?, LASTNAME=?, DOB=? WHERE ID=?";
        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT);) {
            s.clearParameters();
            s.setString(1, p.getFirstName());
            s.setString(2, p.getLastName());
            s.setDate(3, java.sql.Date.valueOf(p.getDOB()));
            s.setLong(4, p.getID());
            s.executeUpdate();
            s.getConnection().commit();
            return p;
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
        return p;
    }

    @Override
    public void delete(Person p) {
        final String STMT = "DELETE FROM " + PERSONS_TABLE + " WHERE ID=?";
        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT);) {
            s.clearParameters();
            s.setLong(1, p.getID());
            s.executeUpdate();
            s.getConnection().commit();
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Person> find(String query, int limit, int offset) {
        final String STMT = "SELECT ID, FIRSTNAME, LASTNAME, DOB FROM (SELECT ID, FIRSTNAME, LASTNAME, LASTNAME_UPPER, DOB FROM "
                + PERSONS_TABLE
                + " WHERE LASTNAME_UPPER LIKE ? UNION SELECT ID, FIRSTNAME, LASTNAME, LASTNAME_UPPER, DOB FROM "
                + PERSONS_TABLE
                + " WHERE FIRSTNAME_UPPER LIKE ?) AS TMP ORDER BY LASTNAME_UPPER OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

        final String searchStr = query.toUpperCase().replace("!", "!!").replace("%", "!%").replace("_", "!_")
                .replace("[", "![") + "%";

        final List<Person> persons = new ArrayList<>();

        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT);) {
            s.clearParameters();
            s.setString(1, searchStr);
            s.setString(2, searchStr);
            s.setInt(3, offset);
            s.setInt(4, limit);

            try (final ResultSet result = s.executeQuery()) {
                while (result.next()) {
                    final int ID = result.getInt("ID");
                    final String lastName = result.getString("LASTNAME");
                    final String firstName = result.getString("FIRSTNAME");
                    final LocalDate dob = result.getDate("DOB").toLocalDate();
                    Person p = new Person(ID, firstName, lastName, dob);
                    persons.add(p);
                }
            } catch (SQLException e) {
                LOG.log(Level.SEVERE, "Error searching persons.", e);
            }
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
        return persons;
    }

    @Override
    public long count() {
        final String STMT = "SELECT COUNT(*) FROM " + PERSONS_TABLE;
        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT);) {
            try (final ResultSet result = s.executeQuery()) {
                if (result.next()) {
                    return result.getInt(1);
                }
            } catch (SQLException e) {
                LOG.log(Level.SEVERE, "Error counting persons", e);
            }
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public long count(String query) {
        final String STMT = "SELECT COUNT(*) FROM (SELECT ID FROM "
                + PERSONS_TABLE + " WHERE LASTNAME_UPPER LIKE ? UNION SELECT ID FROM " + PERSONS_TABLE
                + " WHERE FIRSTNAME_UPPER LIKE ?) AS TMP";

        final String searchStr = query.toUpperCase().replace("!", "!!").replace("%", "!%").replace("_", "!_")
                .replace("[", "![") + "%";

        try (final Connection c = getConnection();
                final PreparedStatement s = c.prepareStatement(STMT);) {
            try {
                s.setString(1, searchStr);
                s.setString(2, searchStr);

                try (ResultSet result = s.executeQuery()) {
                    if (result.next()) {
                        return result.getInt(1);
                    }
                }
            } catch (SQLException e) {
                LOG.log(Level.SEVERE, "Error executing person search", e);
            }
        } catch (SQLException ex) {
            LOG.log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public PersonsDAO configure(Properties properties) throws IllegalArgumentException, IllegalStateException {
        // Nothing to configure
        return this;
    }

}
