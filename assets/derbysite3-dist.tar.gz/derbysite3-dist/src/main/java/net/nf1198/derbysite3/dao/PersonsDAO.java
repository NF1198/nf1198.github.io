/*
 * The MIT License
 *
 * Copyright 2016 Nicholas Folse.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package net.nf1198.derbysite3.dao;

import java.util.List;
import java.util.Properties;
import net.nf1198.derbysite3.data.Person;

/**
 * 
 * @author nickfolse
 */
public interface PersonsDAO {
    
    public Person create(Person p);
    
    public Person read(Integer id) throws IllegalArgumentException;
    
    public Person update(Person p);
    
    public void delete(Person p);
    
    public List<Person> find(String query, int limit, int offset);
    
    public long count();
    
    public long count(String query);
    
    public PersonsDAO configure(Properties properties) throws IllegalArgumentException, IllegalStateException;
    
    /**
     *
     * @param properties (Must contain at least one string-typed "CLASS" property specifying
     *                    the fully qualified class name of the PersonsDAO implementation)
     * @return A fully configured PersonsDAO instance
     * @throws ClassNotFoundException
     * @throws IllegalArgumentException
     * @throws IllegalStateException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static PersonsDAO Build(Properties properties) throws ClassNotFoundException, IllegalArgumentException, IllegalStateException, InstantiationException, IllegalAccessException {
        final String classID = properties.getProperty("CLASS");
        if (classID == null) {
            throw new IllegalArgumentException("DAO implementation \"CLASS\" not specified in configuration properties");
        }
        try {
            @SuppressWarnings("unchecked")
            Class<? extends PersonsDAO> daoImplClass = (Class<? extends PersonsDAO>)Class.forName(classID);
            PersonsDAO dao = daoImplClass.newInstance();
            dao.configure(properties);
            return dao;
        } catch (ClassCastException e) {
            throw new IllegalArgumentException("Specified \"CLASS\" does not implement PersonsDAO interface");
        }
    }
    
}
